import { api, getAuthConfig, getApiBaseUrl } from "@/lib/axios";
import type {
  GetEmployeesParams,
  GetEmployeesResponse,
  GetEmployeesApiResponse,
} from "@/types/employee";

export async function getEmployees(
  params: GetEmployeesParams,
  accessToken: string
): Promise<GetEmployeesResponse> {
  const { page = 1, limit = 10, sortBy = "createdAt", sortOrder = "desc" } = params;
  const url = `${getApiBaseUrl()}/api/employees`;
  const response = await api.get<GetEmployeesApiResponse>(url, {
    params: { page, limit, sortBy, sortOrder },
    ...getAuthConfig(accessToken),
  });
  const body = response.data;
  if (!body.success || !body.data) {
    throw new Error(body.message ?? "Failed to fetch employees");
  }
  const { data, total, page: p, limit: l } = body.data;
  return { data, total, page: p, limit: l };
}
