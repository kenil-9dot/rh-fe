import { api } from "@/lib/axios";
import type { LoginPayload, LoginApiResponse } from "@/types/auth";

export async function loginUser(
  payload: LoginPayload
): Promise<LoginApiResponse> {
  const response = await api.post<LoginApiResponse>("/api/auth/login", payload);
  return response.data;
}
