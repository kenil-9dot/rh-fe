export default function DashboardPage() {
  return (
    <div className="flex-1 overflow-y-auto p-6">
      <div className="text-xl font-semibold">
        Welcome to Admin Dashboard 🚀
      </div>
    </div>
  );
}
