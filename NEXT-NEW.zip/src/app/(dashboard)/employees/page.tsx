"use client";

import { useState, useEffect, useCallback } from "react";
import { PageActions } from "@/components/common/page-actions";
import { SearchInput } from "@/components/common/search-input";
import { EmployeeFilters } from "@/components/employees/employee-filters";
import { EmployeeGrid } from "@/components/employees/employee-grid";
import { Header } from "@/components/layout/header";
import { Pagination } from "@/components/common/pagination";
import { Button } from "@/components/ui/button";
import { CloudDownload, Plus } from "lucide-react";
import type { Employee, GetEmployeesResponse } from "@/types/employee";

const ITEMS_PER_PAGE = 10;
const DEFAULT_SORT = { sortBy: "createdAt", sortOrder: "desc" } as const;

const BACKEND_URL =
  process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:5000";

async function fetchEmployeesClient(params: {
  page: number;
  limit: number;
  sortBy: string;
  sortOrder: string;
}): Promise<GetEmployeesResponse | { error: string }> {
  const tokenRes = await fetch("/api/auth/token", { credentials: "include" });
  if (!tokenRes.ok) {
    return { error: "Unauthorized" };
  }
  const { token } = (await tokenRes.json()) as { token: string };

  const search = new URLSearchParams({
    page: String(params.page),
    limit: String(params.limit),
    sortBy: params.sortBy,
    sortOrder: params.sortOrder,
  });
  const res = await fetch(`${BACKEND_URL}/api/employees?${search}`, {
    headers: { Authorization: `Bearer ${token}` },
    credentials: "omit",
  });
  const json = await res.json();
  if (!res.ok) {
    return { error: json.error ?? json.message ?? "Failed to fetch employees" };
  }
  if (!json.success || !json.data) {
    return { error: json.message ?? "Failed to fetch employees" };
  }
  const { data, total, page, limit } = json.data;
  return { data, total, page, limit };
}

export default function EmployeesPage() {
  const [currentPage, setCurrentPage] = useState(1);
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [total, setTotal] = useState(0);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchEmployees = useCallback(async (page: number) => {
    setIsLoading(true);
    setError(null);
    const result = await fetchEmployeesClient({
      page,
      limit: ITEMS_PER_PAGE,
      ...DEFAULT_SORT,
    });
    if ("error" in result) {
      setError(result.error);
      setEmployees([]);
      setTotal(0);
    } else {
      setEmployees(result.data);
      setTotal(result.total);
    }
    setIsLoading(false);
  }, []);

  useEffect(() => {
    fetchEmployees(currentPage);
  }, [currentPage, fetchEmployees]);

  const totalPages = Math.max(1, Math.ceil(total / ITEMS_PER_PAGE));

  const handlePageChange = (page: number) => {
    setCurrentPage(page);
    const contentArea = document.getElementById("employee-content-area");
    if (contentArea) {
      contentArea.scrollTo({ top: 0, behavior: "smooth" });
    }
  };

  return (
    <div className="flex flex-col h-full">
      {/* First Part: Header */}
      <div className="p-6 pb-0 shrink-0">
        <Header
          title={`Employees (${total})`}
          description="All the employees in your organisation are listed here."
          breadcrumb={[
            { label: "Organisation", href: "/organisation" },
            { label: "Employees" },
          ]}
          actions={
            <>
              <Button variant="outline" className="bg-gray-100 text-gray-700 border-gray-200 hover:bg-gray-200 hover:text-gray-900">
                <CloudDownload className="mr-2 h-4 w-4" />
                Import Employees
              </Button>
              <Button className="bg-blue-500 hover:bg-blue-600">
                <Plus className="mr-2 h-4 w-4" />
                Add New Employee
              </Button>
            </>
          }
        />
      </div>

      {/* Second Part: Content (Scrollable) */}
      <div id="employee-content-area" className="flex-1 overflow-y-auto p-6">
        <div className="space-y-6">
          <PageActions>
            <SearchInput placeholder="Search employees..." />
            <EmployeeFilters />
          </PageActions>

          <EmployeeGrid
            employees={employees}
            isLoading={isLoading}
            error={error}
          />
        </div>
      </div>

      {/* Third Part: Pagination Footer */}
      <div className="p-4 shrink-0">
        <Pagination
          currentPage={currentPage}
          totalPages={totalPages}
          onPageChange={handlePageChange}
        />
      </div>
    </div>
  );
}
