import { ReactNode } from "react";
import { Breadcrumb } from "@/components/ui/breadcrumb";

type HeaderProps = {
  title: string;
  description: string;
  breadcrumb: { label: string; href?: string }[];
  actions?: ReactNode;
};

export function Header({ title, description, breadcrumb, actions }: HeaderProps) {
  return (
    <div className="flex flex-col gap-4 px-2 py-2">
      <Breadcrumb items={breadcrumb} />

      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">
            {title}
          </h1>
          <p className="text-sm text-gray-500">
            {description}
          </p>
        </div>

        {actions && (
          <div className="flex items-center gap-2">
            {actions}
          </div>
        )}
      </div>
    </div>
  );
}
