import Image from "next/image";
import { Calendar, Hash, Briefcase } from "lucide-react";
import { Badge } from "@/components/ui/badge";

type EmployeeCardProps = {
  name: string;
  role: string;
  avatar: string;
  empCode: string;
  joiningDate: string;
  tags: string[];
};

export function EmployeeCard({
  name,
  role,
  avatar,
  empCode,
  joiningDate,
  tags,
}: EmployeeCardProps) {
  return (
    <div className="group flex flex-col rounded-2xl bg-white border border-gray-100 p-5 transition-all duration-200 hover:border-indigo-100 hover:-translate-y-1">
      {/* Header with Avatar and Info */}
      <div className="flex items-center gap-4 mb-5">
        <div className="relative h-14 w-14 rounded-full border-2 border-white shadow-sm overflow-hidden shrink-0">
          <Image
            src={avatar}
            alt={name}
            fill
            sizes="56px"
            className="object-cover"
          />
        </div>
        <div className="min-w-0 flex-1">
          <h3 className="font-bold text-gray-900 truncate text-base">{name}</h3>
          <div className="flex items-center text-xs text-gray-500 mt-1">
            <Briefcase size={12} className="mr-1.5 shrink-0 text-indigo-500" />
            <span className="truncate">{role}</span>
          </div>
        </div>
      </div>

      {/* Tags */}
      <div className="flex flex-wrap gap-2 mb-6">
        {tags.map((tag) => (
          <Badge key={tag} variant="soft">
            {tag}
          </Badge>
        ))}
      </div>

      {/* Details Footer */}
      <div className="mt-auto space-y-3 pt-4 border-t border-gray-50">
        <div className="flex items-center justify-between text-sm">
          <div className="flex items-center text-gray-500">
            <Hash size={15} className="mr-2 text-indigo-400" />
            <span>ID</span>
          </div>
          <span className="font-medium text-gray-900 font-mono text-xs bg-gray-50 px-2 py-0.5 rounded">{empCode}</span>
        </div>
        <div className="flex items-center justify-between text-sm">
          <div className="flex items-center text-gray-500">
            <Calendar size={15} className="mr-2 text-indigo-400" />
            <span>Joined</span>
          </div>
          <span className="font-medium text-gray-900">{joiningDate}</span>
        </div>
      </div>
    </div>
  );
}
